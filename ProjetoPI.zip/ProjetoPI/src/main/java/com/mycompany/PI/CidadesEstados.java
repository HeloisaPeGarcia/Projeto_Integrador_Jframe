/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.PI;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Pichau
 */
public class CidadesEstados {
    private final Map<String, List<String>> cidadesPorEstado = new HashMap<>();
   public void inicializarCidadesPorEstado() {
    cidadesPorEstado.put("Acre (AC)", Arrays.asList("Rio Branco", "Cruzeiro do Sul", "Sena Madureira"));
    cidadesPorEstado.put("Alagoas (AL)", Arrays.asList("Maceió", "Arapiraca", "Palmeira dos Índios"));
    cidadesPorEstado.put("Amapá (AP)", Arrays.asList("Macapá", "Santana", "Laranjal do Jari"));
    cidadesPorEstado.put("Amazonas (AM)", Arrays.asList("Manaus", "Parintins", "Itacoatiara"));
    cidadesPorEstado.put("Bahia (BA)", Arrays.asList("Salvador", "Feira de Santana", "Vitória da Conquista"));
    cidadesPorEstado.put("Ceará (CE)", Arrays.asList("Fortaleza", "Caucaia", "Juazeiro do Norte"));
    cidadesPorEstado.put("Distrito Federal (DF)", Arrays.asList("Brasília", "Ceilândia", "Taguatinga"));
    cidadesPorEstado.put("Espírito Santo (ES)", Arrays.asList("Vitória", "Vila Velha", "Cariacica"));
    cidadesPorEstado.put("Goiás (GO)", Arrays.asList("Goiânia", "Aparecida de Goiânia", "Anápolis"));
    cidadesPorEstado.put("Maranhão (MA)", Arrays.asList("São Luís", "Imperatriz", "São José de Ribamar"));
    cidadesPorEstado.put("Mato Grosso (MT)", Arrays.asList("Cuiabá", "Várzea Grande", "Rondonópolis"));
    cidadesPorEstado.put("Mato Grosso do Sul (MS)", Arrays.asList("Campo Grande", "Dourados", "Três Lagoas"));
    cidadesPorEstado.put("Minas Gerais (MG)", Arrays.asList("Belo Horizonte", "Uberlândia", "Contagem"));
    cidadesPorEstado.put("Pará (PA)", Arrays.asList("Belém", "Ananindeua", "Santarém"));
    cidadesPorEstado.put("Paraíba (PB)", Arrays.asList("João Pessoa", "Campina Grande", "Santa Rita"));
    cidadesPorEstado.put("Paraná (PR)", Arrays.asList("Curitiba", "Londrina", "Maringá"));
    cidadesPorEstado.put("Pernambuco (PE)", Arrays.asList("Recife", "Jaboatão dos Guararapes", "Olinda"));
    cidadesPorEstado.put("Piauí (PI)", Arrays.asList("Teresina", "Parnaíba", "Picos"));
    cidadesPorEstado.put("Rio de Janeiro (RJ)", Arrays.asList("Rio de Janeiro", "Niterói", "Duque de Caxias"));
    cidadesPorEstado.put("Rio Grande do Norte (RN)", Arrays.asList("Natal", "Mossoró", "Parnamirim"));
    cidadesPorEstado.put("Rio Grande do Sul (RS)", Arrays.asList("Porto Alegre", "Caxias do Sul", "Canoas"));
    cidadesPorEstado.put("Rondônia (RO)", Arrays.asList("Porto Velho", "Ji-Paraná", "Ariquemes"));
    cidadesPorEstado.put("Roraima (RR)", Arrays.asList("Boa Vista", "Caracaraí", "Rorainópolis"));
    cidadesPorEstado.put("Santa Catarina (SC)", Arrays.asList("Florianópolis", "Joinville", "Blumenau"));
    cidadesPorEstado.put("São Paulo (SP)", Arrays.asList("São Paulo", "Guarulhos", "Campinas"));
    cidadesPorEstado.put("Sergipe (SE)", Arrays.asList("Aracaju", "Nossa Senhora do Socorro", "Lagarto"));
    cidadesPorEstado.put("Tocantins (TO)", Arrays.asList("Palmas", "Araguaína", "Gurupi"));
}

    Object getCidadesPorEstado() {
        return cidadesPorEstado;
    }
}
