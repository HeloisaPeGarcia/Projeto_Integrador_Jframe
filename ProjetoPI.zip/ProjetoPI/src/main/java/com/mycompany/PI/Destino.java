package com.mycompany.PI;


import com.mycompany.PI.Autenticadores.AutenticacaoUsuario;
import com.mycompany.PI.Autenticadores.BuscaNoBancoDeDadosHotel;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import java.util.Map;
import javax.swing.SwingUtilities;
public class Destino extends javax.swing.JFrame {
    

// Encapsulamento

private int periodoTotal;
private String nome ;
private int QntdePessoas;
 private String cpf;
private String email;
private String Senha;
private String NomeHotel1;

    public Destino(String cpf) {
        this.cpf = cpf;
        initComponents();
    }
 
      
      StringBuilder facilidades = new StringBuilder();

    public Destino() {
     
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jToolBar1 = new javax.swing.JToolBar();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        FiltroPainel = new javax.swing.JDesktopPane();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        pesquisar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        endereco = new javax.swing.JTextField();
        comboBoxEstado = new javax.swing.JComboBox<>();
        comboBoxCidade = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        QntDePessoas = new javax.swing.JSpinner();
        precomaximo = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        dias = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaHoteis = new javax.swing.JList<>();
        Pesquisar = new javax.swing.JButton();
        PesquisarporNome = new javax.swing.JTextField();
        Filtro = new javax.swing.JButton();
        VerInfo = new javax.swing.JPanel();
        NomeHotel = new javax.swing.JTextField();
        Descricao = new javax.swing.JTextField();
        CarrinhoDeCompra = new javax.swing.JToggleButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Telefone = new javax.swing.JTextField();
        CalcularPreco = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        avaliacao = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        informacaoAdicionais = new javax.swing.JButton();
        site = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        Facilidades = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        home = new javax.swing.JMenu();
        profile = new javax.swing.JMenu();
        meuperfil = new javax.swing.JMenu();
        Sair1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jToolBar1.setBackground(new java.awt.Color(99, 248, 212));

        jLayeredPane2.setLayout(new java.awt.GridBagLayout());

        FiltroPainel.setBackground(new java.awt.Color(255, 255, 255));
        FiltroPainel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setText("Cidade:");

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel1.setText("ESCOLHA O DESTINO");

        pesquisar.setBackground(new java.awt.Color(0, 153, 153));
        pesquisar.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        pesquisar.setForeground(new java.awt.Color(255, 255, 255));
        pesquisar.setText("Pesquisar");
        pesquisar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisarActionPerformed(evt);
            }
        });

        jLabel2.setText("Endereço:");

        jLabel3.setText("Estado:");

        endereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enderecoActionPerformed(evt);
            }
        });

        comboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Acre (AC)", "Alagoas (AL)", "Amapá (AP)", "Amazonas (AM)", "Bahia (BA)", "Ceará (CE)", "Distrito Federal (DF)", "Espírito Santo (ES)", "Goiás (GO)", "Maranhão (MA)", "Mato Grosso (MT)", "Mato Grosso do Sul (MS)", "Minas Gerais (MG)", "Pará (PA)", "Paraíba (PB)", "Paraná (PR)", "Pernambuco (PE)", "Piauí (PI)", "Rio de Janeiro (RJ)", "Rio Grande do Norte (RN)", "Rio Grande do Sul (RS)", "Rondônia (RO)", "Roraima (RR)", "Santa Catarina (SC)", "São Paulo (SP)", "Sergipe (SE)", "Tocantins (TO)" }));
        comboBoxEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxEstadoActionPerformed(evt);
            }
        });

        comboBoxCidade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "3", "4", " " }));
        comboBoxCidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxCidadeActionPerformed(evt);
            }
        });

        jLabel6.setText("Qnt de dias:");

        jLabel4.setText("Qnt de pessoas:");

        QntDePessoas.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                QntDePessoasStateChanged(evt);
            }
        });

        precomaximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precomaximoActionPerformed(evt);
            }
        });

        jLabel12.setText("Preço máximo:");

        dias.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                diasStateChanged(evt);
            }
        });

        FiltroPainel.setLayer(jLabel5, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(pesquisar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(endereco, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(comboBoxEstado, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(comboBoxCidade, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(jLabel6, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(jLabel4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(QntDePessoas, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(precomaximo, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(jLabel12, javax.swing.JLayeredPane.DEFAULT_LAYER);
        FiltroPainel.setLayer(dias, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout FiltroPainelLayout = new javax.swing.GroupLayout(FiltroPainel);
        FiltroPainel.setLayout(FiltroPainelLayout);
        FiltroPainelLayout.setHorizontalGroup(
            FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FiltroPainelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FiltroPainelLayout.createSequentialGroup()
                        .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, FiltroPainelLayout.createSequentialGroup()
                                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(comboBoxEstado, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(comboBoxCidade, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(QntDePessoas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(endereco, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(FiltroPainelLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel1)
                                .addGap(12, 12, 12))
                            .addGroup(FiltroPainelLayout.createSequentialGroup()
                                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(FiltroPainelLayout.createSequentialGroup()
                                        .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(16, 16, 16))
                                    .addGroup(FiltroPainelLayout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(47, 47, 47)))
                                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(precomaximo, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                                    .addComponent(dias))))
                        .addGap(31, 31, 31))
                    .addGroup(FiltroPainelLayout.createSequentialGroup()
                        .addComponent(pesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        FiltroPainelLayout.setVerticalGroup(
            FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FiltroPainelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(endereco, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(comboBoxEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(QntDePessoas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(precomaximo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(43, 43, 43)
                .addGroup(FiltroPainelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(dias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addComponent(pesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 3;
        gridBagConstraints.ipadx = 320;
        gridBagConstraints.ipady = 415;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 0, 0);
        jLayeredPane2.add(FiltroPainel, gridBagConstraints);

        ListaHoteis.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        ListaHoteis.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ListaHoteisMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ListaHoteisMouseReleased(evt);
            }
        });
        ListaHoteis.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ListaHoteisKeyPressed(evt);
            }
        });
        ListaHoteis.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                ListaHoteisValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(ListaHoteis);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.gridheight = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 390;
        gridBagConstraints.ipady = 628;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 6, 0);
        jLayeredPane2.add(jScrollPane1, gridBagConstraints);

        Pesquisar.setText("Pesquisar");
        Pesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PesquisarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 0, 0);
        jLayeredPane2.add(Pesquisar, gridBagConstraints);

        PesquisarporNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PesquisarporNomeActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 204;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 0, 0);
        jLayeredPane2.add(PesquisarporNome, gridBagConstraints);

        Filtro.setText("🔎");
        Filtro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FiltroActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 23;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 0, 0);
        jLayeredPane2.add(Filtro, gridBagConstraints);

        VerInfo.setBackground(new java.awt.Color(255, 255, 255));

        NomeHotel.setEditable(false);
        NomeHotel.setBackground(new java.awt.Color(255, 255, 255));
        NomeHotel.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        NomeHotel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        NomeHotel.setText("Escolha o seu Hotel");
        NomeHotel.setBorder(null);
        NomeHotel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NomeHotelActionPerformed(evt);
            }
        });

        Descricao.setEditable(false);
        Descricao.setBackground(new java.awt.Color(255, 255, 255));
        Descricao.setBorder(null);
        Descricao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DescricaoActionPerformed(evt);
            }
        });

        CarrinhoDeCompra.setBackground(new java.awt.Color(169, 239, 231));
        CarrinhoDeCompra.setText("🛒");
        CarrinhoDeCompra.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        CarrinhoDeCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CarrinhoDeCompraActionPerformed(evt);
            }
        });

        jLabel8.setText("Total:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Contato:");

        jLabel9.setText("Telefone:");

        Telefone.setEditable(false);
        Telefone.setBackground(new java.awt.Color(255, 255, 255));

        CalcularPreco.setEditable(false);
        CalcularPreco.setBackground(new java.awt.Color(255, 255, 255));
        CalcularPreco.setBorder(null);
        CalcularPreco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalcularPrecoActionPerformed(evt);
            }
        });

        jLabel10.setText("Site:");

        avaliacao.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        avaliacao.setText(" ");
        avaliacao.setBorder(null);
        avaliacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                avaliacaoActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("Avaliação:");

        informacaoAdicionais.setBackground(new java.awt.Color(153, 255, 255));
        informacaoAdicionais.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        informacaoAdicionais.setText("Informações adicionais");
        informacaoAdicionais.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        informacaoAdicionais.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                informacaoAdicionaisActionPerformed(evt);
            }
        });

        site.setEditable(false);
        site.setBackground(new java.awt.Color(255, 255, 255));
        site.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                siteActionPerformed(evt);
            }
        });

        Facilidades.setColumns(20);
        Facilidades.setRows(5);
        jScrollPane2.setViewportView(Facilidades);

        javax.swing.GroupLayout VerInfoLayout = new javax.swing.GroupLayout(VerInfo);
        VerInfo.setLayout(VerInfoLayout);
        VerInfoLayout.setHorizontalGroup(
            VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(VerInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(VerInfoLayout.createSequentialGroup()
                        .addComponent(CarrinhoDeCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(informacaoAdicionais, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CalcularPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, VerInfoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7)
                            .addComponent(Descricao)
                            .addComponent(NomeHotel, javax.swing.GroupLayout.DEFAULT_SIZE, 313, Short.MAX_VALUE)
                            .addGroup(VerInfoLayout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(avaliacao, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(VerInfoLayout.createSequentialGroup()
                                .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(Telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(site, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane2))
                        .addGap(51, 51, 51))))
        );
        VerInfoLayout.setVerticalGroup(
            VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(VerInfoLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(NomeHotel, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(avaliacao, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Descricao, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(Telefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(site, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                .addGroup(VerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CarrinhoDeCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(informacaoAdicionais, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CalcularPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 6;
        gridBagConstraints.ipady = 78;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 6, 6);
        jLayeredPane2.add(VerInfo, gridBagConstraints);

        jToolBar1.add(jLayeredPane2);

        home.setText("Home");
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
        });
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });
        jMenuBar1.add(home);

        profile.setText("Profile");

        meuperfil.setText(" 👤");
        meuperfil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                meuperfilMouseClicked(evt);
            }
        });
        meuperfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meuperfilActionPerformed(evt);
            }
        });
        profile.add(meuperfil);

        Sair1.setText("↪️");
        Sair1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Sair1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Sair1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Sair1MouseClicked(evt);
            }
        });
        Sair1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Sair1ActionPerformed(evt);
            }
        });
        profile.add(Sair1);

        jMenuBar1.add(profile);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked

    }//GEN-LAST:event_homeMouseClicked

    private void Sair1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Sair1MouseClicked
 Login login = new Login();
 login.setVisible(true);
 this.dispose();   
    }//GEN-LAST:event_Sair1MouseClicked

    private void Sair1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Sair1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Sair1ActionPerformed

    private void pesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisarActionPerformed
  String nomeHotel = PesquisarporNome.getText();
        String estado = "";
        String cidade = "";
        String cep = "";
        double precoMaximo = 0.0;

        if (comboBoxEstado.getSelectedIndex() != -1) {
            estado = (String) comboBoxEstado.getSelectedItem();
        }

        if (comboBoxCidade.getSelectedIndex() != -1) {
            cidade = (String) comboBoxCidade.getSelectedItem();
        }

        String precoMaximoStr = precomaximo.getText();
        if (!precoMaximoStr.isEmpty()) {
            try {
                precoMaximo = Double.parseDouble(precoMaximoStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Digite um valor de preço máximo válido.");
                return;
            }
        }

        cep = endereco.getText();

        BuscaNoBancoDeDadosHotel hotelSearch = new BuscaNoBancoDeDadosHotel();
        DefaultListModel<String> listModel = hotelSearch.buscarHoteis(nomeHotel, estado, cidade, cep, precoMaximo);

        ListaHoteis.setModel(listModel);

    }//GEN-LAST:event_pesquisarActionPerformed

    private void ListaHoteisValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_ListaHoteisValueChanged
    
    }//GEN-LAST:event_ListaHoteisValueChanged

    private void ListaHoteisMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ListaHoteisMouseReleased
 
    }//GEN-LAST:event_ListaHoteisMouseReleased

    private void ListaHoteisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ListaHoteisMouseClicked
  int indiceSelecionado = ListaHoteis.getSelectedIndex();
 
        if (indiceSelecionado != -1) {
            BuscaNoBancoDeDadosHotel.HotelDetails hotelDetails = new BuscaNoBancoDeDadosHotel.HotelDetails();
            BuscaNoBancoDeDadosHotel.HotelInfo hotelInfo = hotelDetails.getHotelDetails(indiceSelecionado, periodoTotal);

            if (hotelInfo != null) {
                NomeHotel.setText(hotelInfo.nome);
                Descricao.setText(hotelInfo.descricao);
                Telefone.setText(hotelInfo.telefone);
                site.setText(hotelInfo.site);
                avaliacao.setText(String.valueOf(hotelInfo.numAvaliacoes));
                CalcularPreco.setText(String.valueOf(hotelInfo.precoTotal));

                StringBuilder facilidadesStr = new StringBuilder();
                facilidadesStr.append("Facilidades: ").append(hotelInfo.facilidades).append(", ");
                facilidadesStr.append("Estacionamento: ").append(hotelInfo.estacionamento).append(", ");
                facilidadesStr.append("Piscina: ").append(hotelInfo.piscina).append(", ");
                facilidadesStr.append("Restaurante: ").append(hotelInfo.restaurante).append(", ");
                facilidadesStr.append("Academia: ").append(hotelInfo.academia).append(", ");
                facilidadesStr.append("Wi-Fi: ").append(hotelInfo.wiFi).append(", ");
                facilidadesStr.append("Animais de Estimação: ").append(hotelInfo.animaisEstimacao).append(", ");
                
                Facilidades.setText(facilidadesStr.toString());
            }
        }
    }//GEN-LAST:event_ListaHoteisMouseClicked

    private void PesquisarporNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PesquisarporNomeActionPerformed

    }//GEN-LAST:event_PesquisarporNomeActionPerformed

    private void PesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PesquisarActionPerformed
 String nomeHotel = PesquisarporNome.getText(); // Obtém o nome do hotel a ser pesquisado

    // Chama a função searchHotels da classe BuscaNoBancoDeDadosHotel
    DefaultListModel<String> listModel = BuscaNoBancoDeDadosHotel.searchHotels(nomeHotel);

    // Define o modelo da lista de hotéis
    ListaHoteis.setModel(listModel);
    }//GEN-LAST:event_PesquisarActionPerformed

    private void FiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FiltroActionPerformed
  if (FiltroPainel.isVisible()) {
        FiltroPainel.setVisible(false); // Se estiver visível, oculta
    } else {
        FiltroPainel.setVisible(true); // Se estiver oculto, exibe
    }

    }//GEN-LAST:event_FiltroActionPerformed

    private void enderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enderecoActionPerformed
        
    }//GEN-LAST:event_enderecoActionPerformed

    private void comboBoxEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxEstadoActionPerformed
 CidadesEstados cidadesEEstados = new CidadesEstados();
    cidadesEEstados.inicializarCidadesPorEstado();

    // Restante do seu código...
    comboBoxCidade.removeAllItems();
    // Obtém o estado selecionado na combo box de estados
    String estadoSelecionado = (String) comboBoxEstado.getSelectedItem();
    // Obtém o mapa de cidades correspondente aos estados
    Map<String, List<String>> cidadesPorEstado = (Map<String, List<String>>) cidadesEEstados.getCidadesPorEstado();
    // Obtém a lista de cidades correspondente ao estado selecionado
    List<String> cidades = cidadesPorEstado.get(estadoSelecionado);
    // Adiciona as cidades na combo box de cidades
    if (cidades != null) {
        for (String cidade : cidades) {
            comboBoxCidade.addItem(cidade);
        }
    }
    }//GEN-LAST:event_comboBoxEstadoActionPerformed

    private void comboBoxCidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxCidadeActionPerformed
  
    }//GEN-LAST:event_comboBoxCidadeActionPerformed

    private void QntDePessoasStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_QntDePessoasStateChanged
    
     QntdePessoas = (int)  QntDePessoas.getValue(); 
    }//GEN-LAST:event_QntDePessoasStateChanged

    private void CarrinhoDeCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CarrinhoDeCompraActionPerformed
   String status = "Pendente"; // Status inicial da compra
    

    boolean sucesso = AutenticacaoUsuario.registrarCompra(cpf, NomeHotel1, QntdePessoas, status, periodoTotal);

    if (sucesso) {
        SwingUtilities.invokeLater(() -> {
            JOptionPane.showMessageDialog(null, "Pedido registrado com sucesso");
            Compraa compra = new Compraa();
            compra.setCPF(cpf);
            compra.setNomeHotel(NomeHotel1);
            compra.setQntpessoas(QntdePessoas);
            compra.setStatus(status);
            compra.setPeriodo(periodoTotal);
            compra.setVisible(true);
        });
    } else {
         JOptionPane.showMessageDialog(null, "Erro ao registrar a compra");
    }

    }//GEN-LAST:event_CarrinhoDeCompraActionPerformed
   
    private void DescricaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DescricaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DescricaoActionPerformed

    private void NomeHotelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NomeHotelActionPerformed
   
    }//GEN-LAST:event_NomeHotelActionPerformed

    private void ListaHoteisKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ListaHoteisKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_ListaHoteisKeyPressed

    private void avaliacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_avaliacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_avaliacaoActionPerformed

    private void informacaoAdicionaisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_informacaoAdicionaisActionPerformed
   JOptionPane.showMessageDialog(null, facilidades);

    }//GEN-LAST:event_informacaoAdicionaisActionPerformed

    private void precomaximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precomaximoActionPerformed
 
    }//GEN-LAST:event_precomaximoActionPerformed

    private void CalcularPrecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalcularPrecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CalcularPrecoActionPerformed

    private void siteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_siteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_siteActionPerformed

    private void meuperfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meuperfilActionPerformed
        

    }//GEN-LAST:event_meuperfilActionPerformed

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed

    }//GEN-LAST:event_homeActionPerformed

    private void meuperfilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_meuperfilMouseClicked
   String DB_URL = "jdbc:mysql://localhost:3306/registrados";
    String USER = "root";
     String PASS = "1234";
    
     Connection conn = null;
         try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (ClassNotFoundException | SQLException e) {
        }
        PreparedStatement pstmt = null;
        if (cpf != null && !cpf.isEmpty()) {
            try {
                String sql = "SELECT * FROM usuarios WHERE cpf = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, cpf);

                // Processar os resultados
                try ( // Executar a consulta
                        ResultSet rs = pstmt.executeQuery()) {
                    // Processar os resultados
                  if (rs.next()) {
    nome = rs.getString("nome");
    email = rs.getString("email");
    Senha = rs.getString("senha");
      MeusDados meusDados = new MeusDados();

        // Passa os valores para a tela MeusDados
        meusDados.setNome(nome);
        meusDados.setEmail(email);
        meusDados.setSenha(Senha);
        meusDados.setCpf(cpf);
        // Exibe a tela MeusDados
        meusDados.setVisible(true);
}

                    // Fechar o ResultSet
                }
            } catch (SQLException se) {
            } finally {
                // Fechar PreparedStatement
                try {
                    if (pstmt != null) pstmt.close();
                } catch (SQLException se) {
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Olá! Entre ou cadastre-se para poder comprar conosco.");
        }

    }//GEN-LAST:event_meuperfilMouseClicked

    private void diasStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_diasStateChanged
           periodoTotal = (Integer) dias.getValue();
    }//GEN-LAST:event_diasStateChanged


 public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(() -> {

        new Destino().setVisible(true);
    });
}

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CalcularPreco;
    public javax.swing.JToggleButton CarrinhoDeCompra;
    private javax.swing.JTextField Descricao;
    private javax.swing.JTextArea Facilidades;
    private javax.swing.JButton Filtro;
    private javax.swing.JDesktopPane FiltroPainel;
    public javax.swing.JList<String> ListaHoteis;
    private javax.swing.JTextField NomeHotel;
    public javax.swing.JButton Pesquisar;
    private javax.swing.JTextField PesquisarporNome;
    public javax.swing.JSpinner QntDePessoas;
    public javax.swing.JMenu Sair1;
    private javax.swing.JTextField Telefone;
    private javax.swing.JPanel VerInfo;
    private javax.swing.JTextField avaliacao;
    public javax.swing.JComboBox<String> comboBoxCidade;
    private javax.swing.JComboBox<String> comboBoxEstado;
    private javax.swing.JSpinner dias;
    public javax.swing.JTextField endereco;
    private javax.swing.JMenu home;
    private javax.swing.JButton informacaoAdicionais;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane2;
    public javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JMenu meuperfil;
    public javax.swing.JButton pesquisar;
    public javax.swing.JTextField precomaximo;
    private javax.swing.JMenu profile;
    private javax.swing.JTextField site;
    // End of variables declaration//GEN-END:variables

    

}

   



