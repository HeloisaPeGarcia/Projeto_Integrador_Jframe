package com.mycompany.PI;

import javax.swing.JFrame;

public class Iniciar extends JFrame {


    // Método main para iniciar o aplicativo
    public static void main(String[] args) {
    Login login = new Login();
        login.setVisible(true);  
    }
}
