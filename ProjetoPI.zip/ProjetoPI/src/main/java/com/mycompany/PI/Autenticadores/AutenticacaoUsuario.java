/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.PI.Autenticadores;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

public class AutenticacaoUsuario {
//Acesso ao banco de dados para saber se o usuário existe ou não
    public boolean autenticarUsuario(String cpf, String senha) {
        ConectorComBancoDeDados conector = new ConectorComBancoDeDados(); // Criar uma instância da classe
        // SQL query para verificar se as credenciais são válidas
        String sql = "SELECT * FROM usuarios WHERE cpf = ? AND senha = ?";

        try (Connection conn = conector.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, cpf);
            pstmt.setString(2, senha);

            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // Credenciais válidas
            // Credenciais inválidas

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao verificar credenciais: " + e.getMessage());
            return false; // Erro ao verificar credenciais
        }
    }
    
    //Valição do usuário
    
      boolean validarCPF(String cpf) {
        // Remover caracteres não numéricos
        cpf = cpf.replaceAll("[^0-9]", "");

        // Verificar se o CPF tem 11 dígitos
        if (cpf.length() != 11) {
            return false;
        }

        // Calcular o primeiro dígito verificador
        int soma = 0;
        for (int i = 0; i < 9; i++) {
            soma += Integer.parseInt(String.valueOf(cpf.charAt(i))) * (10 - i);
        }
        int primeiroDigito = 11 - (soma % 11);
        if (primeiroDigito > 9) {
            primeiroDigito = 0;
        }

        // Calcular o segundo dígito verificador
        soma = 0;
        for (int i = 0; i < 10; i++) {
            soma += Integer.parseInt(String.valueOf(cpf.charAt(i))) * (11 - i);
        }
        int segundoDigito = 11 - (soma % 11);
        if (segundoDigito > 9) {
            segundoDigito = 0;
        }

        // Verificar se os dígitos verificadores são válidos
        return Integer.parseInt(String.valueOf(cpf.charAt(9))) == primeiroDigito &&
                Integer.parseInt(String.valueOf(cpf.charAt(10))) == segundoDigito;
    }
      
      
      // Verifica os outros campos e permite ou não o cadastro do usuário
        public  boolean validarCamposUsuario(String nome, String cpf, String email, String senha) {
        boolean camposValidos = true;

        if (nome.isBlank() || cpf.isBlank() || email.isBlank() || senha.isBlank()) {
            JOptionPane.showMessageDialog(null, "Verifique os campos em branco e tente novamente!");
            camposValidos = false;
        }

        if (nome.length() < 3 || nome.length() > 50) {
             JOptionPane.showMessageDialog(null, "Nome inválido");
            camposValidos = false;
        }

        if (!nome.matches("^[a-zA-ZÀ-ÿ\\s'-]+$")) {
            camposValidos = false;
        }

        if (senha.length() < 8) {
            JOptionPane.showMessageDialog(null, "Sua senha deve possuir pelo menos 7 caracteres ");
            camposValidos = false;
        }

        if (!validarCPF(cpf)) {
            JOptionPane.showMessageDialog(null, "CPF inválido.");
            camposValidos = false;
        }

        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(null, "Email inválido.");
            camposValidos = false;
        }

        return camposValidos;
    }
     
      
      public class AlterarDados {
    private static final String URL = "jdbc:mysql://localhost:3306/registrados";
    private static final String USER = "root";
    private static final String PASSWORD = "1234";

    public static void atualizarUsuario(String nome, String email, String senha, String cpf) {
        // Verifique se os campos não estão vazios
        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty() || cpf.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Conecta ao banco de dados
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

            // SQL para atualizar o registro
            String sql = "UPDATE usuarios SET Nome = ?, email = ?, senha = ? WHERE cpf = ?";

            // Prepara a declaração SQL
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nome);
            pstmt.setString(2, email);
            pstmt.setString(3, senha);
            pstmt.setString(4, cpf);

            // Executa a atualização
            int rowsAffected = pstmt.executeUpdate();

            // Verifica se a atualização foi bem-sucedida
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Informações atualizadas com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao atualizar as informações.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AutenticacaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            // Fecha a conexão e o PreparedStatement
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AutenticacaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AutenticacaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    } 
}
 
    public static boolean registrarCompra(String cpf, String nomeHotel, int quantidadePessoas, String status, int periodo) {
        ConectorComBancoDeDados conector = new ConectorComBancoDeDados();
        String sqlCompra = "INSERT INTO compra (cpf_usuario, Nome_Hotel, quantidade_pessoas, Status, Periodo) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = conector.getConnection();
             PreparedStatement pstmtCompra = conn.prepareStatement(sqlCompra)) {

            pstmtCompra.setString(1, cpf);
            pstmtCompra.setString(2, nomeHotel);
            pstmtCompra.setInt(3, quantidadePessoas);
            pstmtCompra.setString(4, status);
            pstmtCompra.setInt(5, periodo);

            int rowsAffected = pstmtCompra.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao registrar a compra: " + ex.getMessage());
            return false;
        }
    }
    
    
}   

