/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.PI;

import com.mycompany.PI.FormasDePagamento.Cartao;
import com.mycompany.PI.FormasDePagamento.PIX;
import static com.mycompany.PI.Compraa.BarcodeGenerator.generateBarcodeImage;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import net.sourceforge.barbecue.Barcode;
import net.sourceforge.barbecue.BarcodeException;
import net.sourceforge.barbecue.BarcodeFactory;
import net.sourceforge.barbecue.BarcodeImageHandler;
import net.sourceforge.barbecue.output.OutputException;

/**
 * Classe Compraa - Representa a tela de compra de um sistema de reservas de hotel.
 * Responsável por exibir as opções de pagamento e detalhes da reserva.
 */
public class Compraa extends javax.swing.JFrame {
    
// Essas variáveis são privadas para proteger os dados da classe Compraa e só podem ser acessadas ou modificadas 
// por meio de métodos públicos (getters e setters). Isso é um exemplo de encapsulamento, que ajuda a manter 
// a integridade e a segurança dos dados, controlando como eles são manipulados.
    private String cpf;
    private String nomeHotel;
    private int qntpessoas;
    private String status;
    private int periodo;
    
 // Construtor da classe Compraa
    public Compraa() {
        initComponents();
    }
    
    // Métodos setters
  public void setCPF(String cpf) {
        this.cpf = cpf;
    }
    public void setNomeHotel(String nomeHotel) {
        this.nomeHotel = nomeHotel;
    }

    public void setQntpessoas(int qntpessoas) {
        this.qntpessoas = qntpessoas;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setPeriodo(int periodo) {
        this.periodo = periodo;
    }

//Gerador de código de barras
public class BarcodeGenerator {

    public static Image generateBarcodeImage(String data) {
        try {
            // Cria um objeto de código de barras
            Barcode barcode = BarcodeFactory.createCode128(data);

            // Gera a imagem do código de barras
            return BarcodeImageHandler.getImage(barcode);
        } catch (BarcodeException | OutputException e) {
            return null;
        }
    }
    }
        Image barcodeImage = generateBarcodeImage("123456789");
        
        public static void displayBarcodeImage(Image barcodeImage) {
        if (barcodeImage != null) {
            // Cria um JFrame para exibir a imagem
            JFrame frame = new JFrame("Código de Barras");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(400, 300);

            // Cria um JPanel personalizado para desenhar a imagem
            JPanel panel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    g.drawImage(barcodeImage, 10, 10, this);
                }
            };

            // Adiciona o painel ao frame e exibe a janela
            frame.add(panel);
            frame.setVisible(true);
        } else {
              JOptionPane.showMessageDialog(null,"Falha ao gerar a imagem do código de barras.");
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        voltar = new javax.swing.JButton();
        cartao = new javax.swing.JToggleButton();
        pix = new javax.swing.JToggleButton();
        boleto = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        voltar.setBackground(new java.awt.Color(0, 204, 204));
        voltar.setForeground(new java.awt.Color(255, 255, 255));
        voltar.setText(" ⬅️");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53))
        );

        cartao.setBackground(new java.awt.Color(148, 224, 195));
        cartao.setText("CARTÃO DE CRÉDITO");
        cartao.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cartaoActionPerformed(evt);
            }
        });

        pix.setBackground(new java.awt.Color(216, 249, 236));
        pix.setText("PIX");
        pix.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pix.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pixActionPerformed(evt);
            }
        });

        boleto.setBackground(new java.awt.Color(153, 202, 198));
        boleto.setText("BOLETO");
        boleto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boleto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boletoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(boleto, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pix, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cartao, javax.swing.GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(270, Short.MAX_VALUE)
                .addComponent(pix, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(boleto, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(cartao, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(259, 259, 259))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
  Destino destino = new Destino();
        destino.setVisible(true);  
     this.dispose();
    }//GEN-LAST:event_voltarActionPerformed

    private void pixActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pixActionPerformed
        PIX Pix = new PIX();
        Pix.setVisible(true);
    }//GEN-LAST:event_pixActionPerformed

    private void boletoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boletoActionPerformed
   String data = "123456789";
        barcodeImage = generateBarcodeImage(data);
        displayBarcodeImage(barcodeImage);
    }//GEN-LAST:event_boletoActionPerformed

    private void cartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cartaoActionPerformed
Cartao cartao = new Cartao();
cartao.setVisible(true);

    }//GEN-LAST:event_cartaoActionPerformed

    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(() -> {
            new Compraa().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton boleto;
    private javax.swing.JToggleButton cartao;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JToggleButton pix;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables

  
}
