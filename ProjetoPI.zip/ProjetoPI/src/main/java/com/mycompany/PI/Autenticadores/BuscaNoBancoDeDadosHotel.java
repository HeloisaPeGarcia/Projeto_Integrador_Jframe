package com.mycompany.PI.Autenticadores;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class BuscaNoBancoDeDadosHotel {
    private static final String URL = "jdbc:mysql://localhost:3306/registrados"; // URL de conexão com o banco de dados
    private static final String USER = "root"; // Nome de usuário do banco de dados
    private static final String PASSWORD = "1234"; // Senha do banco de dados

    public DefaultListModel<String> buscarHoteis(String nomeHotel, String estado, String cidade, String cep, double precoMaximo) {
        DefaultListModel<String> listModel = new DefaultListModel<>();

        String query = "SELECT * FROM Hoteis WHERE 1=1";
        
        if (!nomeHotel.isEmpty()) {
            query += " AND nome LIKE ?";
        }

        if (!estado.isEmpty()) {
            query += " AND estado LIKE ?";
        }

        if (!cidade.isEmpty()) {
            query += " AND cidade LIKE ?";
        }

        if (!cep.isEmpty()) {
            query += " AND endereco LIKE ?";
        }

        if (precoMaximo > 0.0) {
            query += " AND preco <= ?";
        }

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            int index = 1;

            if (!nomeHotel.isEmpty()) {
                pstmt.setString(index++, "%" + nomeHotel + "%");
            }

            if (!estado.isEmpty()) {
                pstmt.setString(index++, "%" + estado + "%");
            }

            if (!cidade.isEmpty()) {
                pstmt.setString(index++, "%" + cidade + "%");
            }

            if (!cep.isEmpty()) {
                pstmt.setString(index++, "%" + cep + "%");
            }

            if (precoMaximo > 0.0) {
                pstmt.setDouble(index++, precoMaximo);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String nome = rs.getString("nome");
                    listModel.addElement(nome);
                    // Você também pode exibir outras informações do hotel, se desejar
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar a consulta SQL: " + e.getMessage());
        }

        return listModel;
    }
    
    public static class HotelInfo {
        public String nome;
        public String endereco;
        public String cidade;
        public String estado;
        public String cep;
        public double preco;
        public String descricao;
        public String categoria;
        public Time checkIn;
        public Time checkOut;
        public String telefone;
        public String email;
        public String site;
        public String facilidades;
        public float avaliacao;
        public int numAvaliacoes;
        public boolean estacionamento;
        public boolean piscina;
        public boolean restaurante;
        public boolean academia;
        public boolean wiFi;
        public boolean animaisEstimacao;
        public String imagemUrl;
        public Timestamp dataCadastro;
        public double precoTotal;

        public HotelInfo(String nome, String endereco, String cidade, String estado, String cep, double preco, String descricao,
                         String categoria, Time checkIn, Time checkOut, String telefone, String email, String site,
                         String facilidades, float avaliacao, int numAvaliacoes, boolean estacionamento, boolean piscina,
                         boolean restaurante, boolean academia, boolean wiFi, boolean animaisEstimacao, String imagemUrl,
                         Timestamp dataCadastro, int periodoTotal) {
            this.nome = nome;
            this.endereco = endereco;
            this.cidade = cidade;
            this.estado = estado;
            this.cep = cep;
            this.preco = preco;
            this.descricao = descricao;
            this.categoria = categoria;
            this.checkIn = checkIn;
            this.checkOut = checkOut;
            this.telefone = telefone;
            this.email = email;
            this.site = site;
            this.facilidades = facilidades;
            this.avaliacao = avaliacao;
            this.numAvaliacoes = numAvaliacoes;
            this.estacionamento = estacionamento;
            this.piscina = piscina;
            this.restaurante = restaurante;
            this.academia = academia;
            this.wiFi = wiFi;
            this.animaisEstimacao = animaisEstimacao;
            this.imagemUrl = imagemUrl;
            this.dataCadastro = dataCadastro;
            this.precoTotal = preco * periodoTotal;
        }
    }
    
    public static class HotelDetails {
        public HotelInfo getHotelDetails(int selectedIndex, int periodoTotal) {
            String query = "SELECT * FROM Hoteis LIMIT ?, 1";
            
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, selectedIndex);
                
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        return new HotelInfo(
                            rs.getString("nome"),
                            rs.getString("endereco"),
                            rs.getString("cidade"),
                            rs.getString("estado"),
                            rs.getString("cep"),
                            rs.getDouble("preco"),
                            rs.getString("descricao"),
                            rs.getString("categoria"),
                            rs.getTime("check_in"),
                            rs.getTime("check_out"),
                            rs.getString("telefone"),
                            rs.getString("email"),
                            rs.getString("site"),
                            rs.getString("facilidades"),
                            rs.getFloat("avaliacao"),
                            rs.getInt("num_avaliacoes"),
                            rs.getBoolean("estacionamento"),
                            rs.getBoolean("piscina"),
                            rs.getBoolean("restaurante"),
                            rs.getBoolean("academia"),
                            rs.getBoolean("wi_fi"),
                            rs.getBoolean("animais_estimacao"),
                            rs.getString("imagem_url"),
                            rs.getTimestamp("data_cadastro"),
                            periodoTotal
                        );
                    }
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao executar a consulta SQL: " + e.getMessage());
            }
            return null;
        }
    }
    
    
    public static DefaultListModel<String> searchHotels(String nomeHotel) {
        ConectorComBancoDeDados conector = new ConectorComBancoDeDados();
        String query = "SELECT * FROM Hoteis WHERE nome LIKE ?";

        DefaultListModel<String> listModel = new DefaultListModel<>();

        try (Connection conn =  conector.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, "%" + nomeHotel + "%"); // Configura o parâmetro da consulta

            try (ResultSet rs = pstmt.executeQuery()) {
                // Limpa a lista de hotéis antes de adicionar novos resultados
                listModel.clear();

                while (rs.next()) {
                    String nome = rs.getString("nome");
                    // Adiciona o nome do hotel ao modelo da lista
                    listModel.addElement(nome);
                    // Você também pode exibir outras informações do hotel, se desejar
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar a consulta SQL: " + e.getMessage());
        }

        return listModel;
    
}
}
